
Tajawal Open-Source Font

It is a distinctive modern Arabic typeface, available in seven weights. 
The range was created by Boutros following a modern geometric style 
while still respecting Arabic calligraphy rules. 

Its fluid geometry makes Tajawal the perfect choice to use in both 
print and web applications, and alongside its matching Latin typefaces.

![Tajawal Fonts](docs/sample.png)
