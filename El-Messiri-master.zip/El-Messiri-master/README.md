# El Messiri 

![Sample](documentation/sample.png)

**El Messiri** is a modern Arabic typeface family designed by Mohamed Gaber (Arabic) that began with Jovanny Lemonad's Latin and Cyrillic typeface Philosopher.

The Arabic started with the concept of a curvy Arabic typeface inspired by the beauty of Naskh and drawn as if with a brush instead of the traditional bamboo pen. 
The idea took form with wide counters that improve readability at smaller text sizes, and has subtle details that make it a great display face at larger sizes. 

El Messiri current comes in 4 weights (Light, Regular, SemiBold and Bold) and the Arabic component has a wide glyph set that supports the Arabic, Farsi and Urdu languages.

The El Messiri project is led by Mohamed Gaber, a type designer based in Cairo, Egypt. 
To contribute, see [github.com/Gue3bara/El-Messiri](https://github.com/Gue3bara/El-Messiri)
