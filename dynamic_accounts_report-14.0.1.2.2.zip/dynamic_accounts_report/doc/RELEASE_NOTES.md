## Module <dynamic_accounts_report>

#### 03.05.2021
#### Version 14.0.1.0.0
#### ADD
- Initial commit for Odoo 14 dynamic financial reports

#### 21.05.2021
#### Version 14.0.1.1.1
#### UPDT
- Updated Style and Currency Format

#### 27.05.2021
#### Version 14.0.1.2.1
#### UPDT
- Ageing Report.


#### 28.06.2021
#### Version 14.0.1.2.2
#### UPDT
- Updated



