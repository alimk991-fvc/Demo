## Module <base_accounting_kit>

#### 03.10.2020
#### Version 14.0.1.0.0
#### ADD
- Initial commit for Odoo 14 accounting

#### 13.10.2020
#### Version 14.0.1.1.1
#### UPDT
- Trial Balane missing issue updated

#### 18.10.2020
#### Version 14.0.1.2.2
#### UPDT
- Added action in dashboard

#### 18.11.2020
#### Version 14.0.1.3.3
#### UPDT
- Field parameter spelling mistake updated.

#### 05.01.2021
#### Version 14.0.1.4.4
#### UPDT
- Removed warnings, Updated access rules.

#### 18.01.2021
#### Version 14.0.2.4.4
#### UPDT
- Reconciliation Widget Added.

#### 12.02.2021
#### Version 14.0.2.5.4
#### UPDT
- Translation Added

#### 25.02.2021
#### Version 14.0.2.5.5
#### UPDT
- Bank Book, Cash Book Issue updated
- Tax report Issue updated
- Asset Issue updated


#### 05.04.2021
#### Version 14.0.2.7.6
#### UPDT
- Reconcilation issue.

#### 27.04.2021
#### Version 14.0.3.7.7
#### UPDT
- Multiple Invoice Copies added.

#### 03.05.2021
#### Version 14.0.3.8.8
#### UPDT
- Budget added as depend
- Removed the budget option of enterprise


#### 03.05.2021
#### Version 14.0.3.9.8
#### UPDT
- Cash flow style updated

#### 24.05.2021
#### Version 14.0.3.10.8
#### UPDT
- Report Configuration Sequence

#### 28.05.2021
#### Version 14.0.3.11.9
#### UPDT
- 2 * Dashboard Issue
- Report Configuration Sequence

#### 17.06.2021
#### Version 14.0.3.11.10
#### FIX
- Invalid field 'post_at' in Journal - issue fixed

#### 05.07.2021
#### Version 14.0.3.11.11
#### FIX
- 'Journal entry already posted' issue fixed.

